<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Property_images extends Model
{
    public $table = 'property_images';
}
